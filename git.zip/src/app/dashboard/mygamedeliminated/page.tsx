import Home from '@/components/dashboard/mygamedeliminated/Home'
import React from 'react'

const page = () => {
  return (
    <Home/>
  )
}

export default page