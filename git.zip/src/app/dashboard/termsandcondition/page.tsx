import Home from '@/components/dashboard/termsandcondition/Home'
import React from 'react'

const page = () => {
  return (
    <Home/>
  )
}

export default page