import Home from '@/components/dashboard/dashboardhome/Home'
import React from 'react'

const page = () => {
  return (
    <Home/>
  )
}

export default page