import Home from '@/components/website/login/Home'
import React from 'react'

const page = () => {
  return (
    <Home/>
  )
}

export default page