import React from 'react'
import BackLink from './BackLink'
import FormCard from './FormCard'

const SignUpusingMail = () => {
  return (
    <>
      <BackLink/>
      <FormCard/>
    </>
  )
}

export default SignUpusingMail
