'use client'
import React from 'react'
import BackLink from './BackLink'
import FormCard from './FormCard'

const EmailVerification = () => {
  return (
    <>
      <BackLink/>
      <FormCard/>
      </>
  )
}

export default EmailVerification
