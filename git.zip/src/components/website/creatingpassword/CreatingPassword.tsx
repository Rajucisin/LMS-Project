import React from 'react'
import BackLink from './BackLink'
import FormCard from './FormCard'

const CreatingPassword = () => {
  return (
     <>
      <BackLink/>
      <FormCard/>
    </>
  )
}

export default CreatingPassword
