import React from 'react'
import BackLink from './BackLink'
import FormCard from './FormCard'

const ResetPassword = () => {
  return (
    <div>
      <BackLink/>
      <FormCard/>
    </div>
  )
}

export default ResetPassword
