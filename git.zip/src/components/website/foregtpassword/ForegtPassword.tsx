import Link from 'next/link'
import React from 'react'
import Image from "next/image";
import BackLink from './BackLink';
import FormCard from './FormCard';

const ForegtPassword = () => {
  return (
    <>
      <BackLink/>
      <FormCard />
      </>
  )
}

export default ForegtPassword
