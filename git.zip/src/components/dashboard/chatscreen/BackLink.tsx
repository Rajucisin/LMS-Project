import Link from 'next/link'
import React from 'react'
import Image from "next/image";

import GameLogo1 from "../../../../public/images/explore-game-logo-img-1.png";

const BackLink = () => {
    return (
        <div className='back-toolbar bg-gray'>
            <div className='container'>
                <div className='me-auto'>
                    <Link href="" className='d-inline-flex align-items-center'>
                        <div className='icon'>
                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                                <path d="M28.5 16.0004C28.5 16.3982 28.3419 16.7797 28.0606 17.061C27.7793 17.3423 27.3978 17.5004 27 17.5004H8.62496L15.065 23.9391C15.3468 24.2209 15.5051 24.6031 15.5051 25.0016C15.5051 25.4001 15.3468 25.7823 15.065 26.0641C14.7832 26.3459 14.401 26.5042 14.0025 26.5042C13.6039 26.5042 13.2218 26.3459 12.94 26.0641L3.93996 17.0641C3.80012 16.9248 3.68917 16.7592 3.61346 16.5769C3.53775 16.3945 3.49878 16.199 3.49878 16.0016C3.49878 15.8042 3.53775 15.6087 3.61346 15.4264C3.68917 15.2441 3.80012 15.0785 3.93996 14.9391L12.94 5.93913C13.0795 5.7996 13.2451 5.68891 13.4274 5.6134C13.6097 5.53789 13.8051 5.49902 14.0025 5.49902C14.1998 5.49902 14.3952 5.53789 14.5775 5.6134C14.7598 5.68891 14.9254 5.7996 15.065 5.93913C15.2045 6.07865 15.3152 6.2443 15.3907 6.4266C15.4662 6.60891 15.5051 6.8043 15.5051 7.00163C15.5051 7.19895 15.4662 7.39434 15.3907 7.57665C15.3152 7.75895 15.2045 7.9246 15.065 8.06413L8.62496 14.5004H27C27.3978 14.5004 27.7793 14.6584 28.0606 14.9397C28.3419 15.221 28.5 15.6026 28.5 16.0004Z" fill="currentColor" />
                            </svg>
                        </div>
                        <Image src={GameLogo1} alt=''/>
                            <div className='flex-grow-1'>
                                AFL Season 2026
                                <p className='m-0'>123 Players | Round 6</p>
                            </div>
                        </Link>
                </div>
            </div>
        </div>
    )
}

export default BackLink
