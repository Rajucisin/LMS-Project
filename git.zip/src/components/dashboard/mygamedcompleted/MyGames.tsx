import React from 'react'
import MyGamedCompleted from './MyGamedCompleted'


const MyGames = () => {
  return (
    <div className='body-content-sec p-40'>
      <MyGamedCompleted/>
    </div>
  )
}

export default MyGames
