import React from 'react'
import MyGamesActive from './MyGamesActive'

const MyGames = () => {
  return (
    <div className='body-content-sec p-40'>
      <MyGamesActive/>
    </div>
  )
}

export default MyGames
