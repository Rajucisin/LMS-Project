import React from 'react'
import MyGamedEliminated from './MyGamedEliminated'


const MyGames = () => {
  return (
    <div className='body-content-sec p-40'>
      <MyGamedEliminated/>
    </div>
  )
}

export default MyGames
